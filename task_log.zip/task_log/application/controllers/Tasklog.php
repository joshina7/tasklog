<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tasklog extends CI_Controller {

	function __construct()
    {
        parent::__construct();
        $this->load->model('Tasklog_model');
    } 
	
	public function index()
	{
		$this->load->view('home');
	}
	public function login()
	{
		$this->load->view('login');
	}

	function login_exe()
    {
    	if(isset($_POST) && count($_POST) > 0)     
        {
        	$uname=$this->input->post('email');
        	$pwd=$this->input->post('password');
        	$check = $this->Tasklog_model->check_login($uname,$pwd);
        	if($check != NULL)
        	{
        		if($uname==$check['username'] && $pwd==$check['password'])
				{			
					$type=$check['usertype']; 
					$this->session->set_userdata('username',$uname);
					$this->session->set_userdata('usertype',$type);
					redirect("Tasklog/userhome");	  
				}
        	}
        	else
        	{
        		?>
				<script type="text/javascript">
				  alert("Something went wrong..Please try again later");
				  location.href="<?php echo base_url()?>index.php/Tasklog/login";
				 </script>							   
			<?php  
        	}

        }
    }

    public function logout()
	{
		$this->session->unset_userdata('username');
		$this->session->unset_userdata('usertype');
		?>
		
		<script>
			window.location.hash="no-back-button";
			window.location.hash="Again-No-back-button";//again because google chrome don't insert first hash into history
			window.onhashchange=function(){window.location.hash="no-back-button";}
			</script> 
			 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
				 
					<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
					<meta http-equiv="Pragma" content="no-cache" />
					<meta http-equiv="Expires" content="0" />
					<meta http-equiv="Expires" content="0" />
					<meta http-equiv="refresh" content="0; <?php echo site_url()?>/Tasklog/login"?>
		<?php
	}

	public function userhome()
	{
		
		$data['_view'] = 'userhome';
        $this->load->view('dashboard',$data);
	}

	public function add_task()
	{
		$uname=$this->session->userdata('username');
		$data['task'] = $this->Tasklog_model->get_task_by_staff($uname);
		if(isset($_POST) && count($_POST) > 0)     
        {  
            $params = array(
                'task_title' => $this->input->post('tname'),
                'date' => $this->input->post('date'),
                'start_time' => $this->input->post('stime'),
                'end_time' => $this->input->post('etime'),
                'added_by' => $uname,
                'status' => 'new',
            );
            
            $taskid = $this->Tasklog_model->add_tasks($params);
     
           
           
          
        }
        else
        {  
			$data['_view'] = 'add_task';
        	$this->load->view('dashboard',$data);
    	}
	}

	public function task_exe()
	{
		$id = $_REQUEST['i'];
		$status = $_REQUEST['s'];
		if($status=='a')
		{
			$params = array(
             'status' => 'approved',
            );
			$this->Tasklog_model->update_task($id,$params);  
		}

		if($status=='r')
		{
			$params = array(
             'status' => 'rejected',
            );
			$this->Tasklog_model->update_task($id,$params);  
		}
		
		 ?>
				<script type="text/javascript">
				  alert("Success");
				  location.href="<?php echo base_url()?>index.php/Tasklog/view_task?s=new";
				 </script>							   
			<?php   
	}


	public function view_task()
	{
		$status = $_REQUEST['s'];
		$data['all_task'] = $this->Tasklog_model->get_task_by_status($status);
		if($status=='new')
		{
			$data['_view'] = 'task_list';
  			$this->load->view('dashboard',$data);
		}
		elseif($status=='approved')
		{
			$data['_view'] = 'task_list_approved';
  			$this->load->view('dashboard',$data);
		}
		elseif($status=='rejected')
		{
			$data['_view'] = 'task_list_rejected';
  			$this->load->view('dashboard',$data);
		}
		
	}

}
