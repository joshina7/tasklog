<?php
class  Tasklog_model extends CI_Model 
{
	function __construct()
    {
        parent::__construct();
    }

    function check_login($uname,$pwd)
    {
        return $this->db->get_where('login',array('username'=>$uname,'password'=>$pwd))->row_array();
    }
    function get_all_task()
    {
        return $this->db->get_where('tasks',array('status'=>'new'))->result_array();
    }

    function add_tasks($params)
    {
        $this->db->insert('tasks',$params);
        return $this->db->insert_id();
    }

    function update_task($tasks_id,$params)
    {
        $this->db->where('taskid',$tasks_id);
        return $this->db->update('tasks',$params);
    }

    function get_task_by_staff($uname)
    {
        return $this->db->get_where('tasks',array('added_by'=>$uname))->result_array();
    }

     function get_task_by_status($status)
    {
        return $this->db->get_where('tasks',array('status'=>$status))->result_array();
    }

}
