<div class="container">
  <div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Task List</h3>
            	
            </div>
            <div class="box-body">
			<?php
			$si=1;
			?>
                <table class="table table-striped">
                    <tr>
						<th>Sl.No</th>
						<th>Title</th>
						<th>Date</th>
						<th>Start Time</th>
						<th>End Time</th>
						<th>Time Taken For Task</th>
						<th>Added By</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($all_task as $t)
                    { 
                    	$t1=new DateTime($t['start_time']);
                    	$t1->format('h:i:s a');
						$t2=new DateTime($t['end_time']);
						$t2->format('h:i:s a');
						$inter=$t1->diff($t2);
						
                    	?>
                    <tr>
						<td><?php echo $si++; ?></td>
						<td><?php echo $t['task_title']; ?></td>
						<td><?php echo date('d-m-Y',strtotime($t['date'])); ?></td>
						<td><?php echo date('h:i a',strtotime($t['start_time'])); ?></td>
						<td><?php echo date('h:i a',strtotime($t['end_time'])); ?></td>
						<td><?php echo $inter->format('%h')."Hr ".$inter->format('%i')."Min ";  ?></td>
						<td><?php echo $t['added_by']; ?></td>
						<td>
                            <a href="<?php echo site_url('Tasklog/task_exe?i='.$t['taskid'].'&s=a'); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Approve</a> 
                            <a onClick="return confirm('Are You Sure want to reject?');" href="<?php echo site_url('Tasklog/task_exe?i='.$t['taskid'].'&s=r'); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Reject</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>

</div>