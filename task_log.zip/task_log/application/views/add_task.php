<div class="container">
  <div class="row">
    <div class="col-sm">
      <h4>Add Task</h4>
       <form class="form-inline" method="POST" action="<?php echo base_url('index.php/Tasklog/add_task')?>">	  	
		  		<table class="table table-bordered">
		  			<tr>
		  				<th>Task Name :</th>
		  				<td><input type="text" name="tname" class="form-control" required=""></td>
		  			</tr>
		  			<tr>
		  				<th>Date :</th>
		  				<td><input type="date" name="date" class="form-control" required=""></td>
		  			</tr>
		  			<tr>
		  				<th>Start Time :</th>
		  				<td><input type="time" name="stime" class="form-control" required=""></td>
		  			</tr>
		  			<tr>
		  				<th>End Time :</th>
		  				<td><input type="time" name="etime" class="form-control" required=""></td>
		  			</tr>

		  			
		  			<tr> 				
		  				<td colspan="2"><button type="submit" class="btn btn-success">Submit</button></td>
		  			</tr> 		
		  		</table>
		  </form>
    </div>
   
    <div class="col-sm">
      <h4>My Tasks</h4>
       <table class="table table-striped table-bordered">
                    <tr>
						<th>Sl.No</th>
						<th>Title</th>
						<th>Date</th>
						<th>Start Time</th>
						<th>End Time</th>
					
                    </tr>
                    <?php 
                    $i=1;
                    foreach($task as $t)
                    { 
						
                    	?>
                    <tr>
						<td><?php echo $i++; ?></td>
						<td><?php echo $t['task_title']; ?></td>
						<td><?php echo date('d-m-Y',strtotime($t['date'])); ?></td>
						<td><?php echo date('h:i a',strtotime($t['start_time'])); ?></td>
						<td><?php echo date('h:i a',strtotime($t['end_time'])); ?></td>
						
                    </tr>
                    <?php } ?>
                </table>
    </div>
  </div>
</div>