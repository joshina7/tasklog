<!DOCTYPE html>
<html>
<head>
	<title>Task Log</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
</head>
<body>

<body>
<nav class="navbar navbar-expand-sm bg-warning">
    <ul class="navbar-nav">
        <li class="nav-item"><a href="<?php echo site_url('tasklog/index');?>" class="nav-link">Home</a></li>
  
        <li class="nav-item"><a href="<?php echo site_url('tasklog/login');?>" class="nav-link">Login</a></li>
    </ul>
</nav>
<br>
<div class="container">
  <div class="row">
    <div class="col-md">
      <h4>LOGIN</h4>
       <form class="form-inline" method="POST" action="<?php echo base_url('index.php/tasklog/login_exe')?>">	  	
		  		<table class="table table-bordered">
		  			<tr>
		  				<th>Userame/Email</th>
		  				<td><input type="email" name="email" class="form-control" required=""></td>
		  			</tr>
		  			<tr>
		  				<th>Password</th>
		  				<td><input type="password" name="password" class="form-control" required=""></td>
		  			</tr>
					<!--<tr>
		  				<th>Password</th>
		  				<td><input type="password" name="password" class="form-control" required=""></td>
		  			</tr>-->
		  			<tr> 				
		  				<td colspan="2"><button type="submit" class="btn btn-success">Submit</button></td>
		  			</tr> 		
		  		</table>
		  </form>
    </div> 
  </div>
</div>

</body>
</html>