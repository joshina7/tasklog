<div class="container" style="margin-top:50px">
  <div class="row">
    <div class="col-md">

	<h2>WELCOME..<?php echo $this->session->userdata('username') ?></h2>
      
       
    </div> 
  </div>
</div>