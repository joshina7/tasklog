<div class="container">
  <div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Rejected Task List</h3>
            	
            </div>
            <div class="box-body">
			<?php
			$si=1;
			?>
                <table class="table table-striped">
                    <tr>
						<th>Sl.No</th>
						<th>Title</th>
						<th>Date</th>
						<th>Start Time</th>
						<th>End Time</th>
						<th>Time Taken For Task</th>
						<th>Added By</th>
					
                    </tr>
                    <?php foreach($all_task as $t)
                    { 
                    	$t1=new DateTime($t['start_time']);
                    	$t1->format('h:i:s a');
						$t2=new DateTime($t['end_time']);
						$t2->format('h:i:s a');
						$inter=$t1->diff($t2);
						
                    	?>
                    <tr>
						<td><?php echo $si++; ?></td>
						<td><?php echo $t['task_title']; ?></td>
						<td><?php echo date('d-m-Y',strtotime($t['date'])); ?></td>
						<td><?php echo date('h:i a',strtotime($t['start_time'])); ?></td>
						<td><?php echo date('h:i a',strtotime($t['end_time'])); ?></td>
						<td><?php echo $inter->format('%h')."Hr ".$inter->format('%i')."Min ";  ?></td>
						<td><?php echo $t['added_by']; ?></td>
					
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>

</div>