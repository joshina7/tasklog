<?php
$item=$this->session->userdata('username');
$utype=$this->session->userdata('usertype');
if($item==NULL)
{
     return Redirect("Tasklog/login");
    
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Task log User</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
</head>
<body>

<body>
<nav class="navbar navbar-expand-sm bg-warning">
    <ul class="navbar-nav">
    	<?php
		if($utype=='staff')
		{
    	?>
    		<li class="nav-item"><a href="<?php echo site_url('Tasklog/add_task');?>" class="nav-link">Add Task</a></li>
    	<?php
		}
		if($utype=='supervisor')
		{
    	?>
    		<li class="nav-item"><a href="<?php echo site_url('Tasklog/view_task?s=new');?>" class="nav-link">New Task</a></li>
            <li class="nav-item"><a href="<?php echo site_url('Tasklog/view_task?s=approved');?>" class="nav-link">Approved Task</a></li>
            <li class="nav-item"><a href="<?php echo site_url('Tasklog/view_task?s=rejected');?>" class="nav-link">Rejected Task</a></li>
    	<?php
    	}
    	?>
        	<li class="nav-item"><a href="<?php echo site_url('Tasklog/logout');?>" class="nav-link">Logout</a></li>
    </ul>
</nav>

<?php if(isset($_view) && $_view)
      $this->load->view($_view);
  ?>
</body>
</html>